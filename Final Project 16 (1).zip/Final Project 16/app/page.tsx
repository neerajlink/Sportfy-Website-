export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 mb-6">
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </div>
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
            Sports Injury Analysis System
          </h1>
          <p className="text-xl text-slate-400">Flask + Python Application Ready</p>
        </div>

        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="p-3 bg-amber-500/20 rounded-lg">
              <svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                />
              </svg>
            </div>
            <div>
              <h2 className="text-xl font-semibold text-amber-400 mb-2">Important Notice</h2>
              <p className="text-slate-300">
                This is a <strong>Flask/Python application</strong> that cannot run in v0's browser preview. The preview
                only supports Next.js/React applications.
              </p>
            </div>
          </div>

          <div className="bg-slate-900/50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-cyan-400 mb-4 flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                />
              </svg>
              How to Run Your Flask App
            </h3>
            <ol className="space-y-4 text-slate-300">
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-7 h-7 bg-cyan-500/20 text-cyan-400 rounded-full flex items-center justify-center text-sm font-bold">
                  1
                </span>
                <div>
                  <strong className="text-white">Download the project</strong>
                  <p className="text-sm text-slate-400 mt-1">
                    Click the three dots menu (⋮) in the top right → Select "Download ZIP"
                  </p>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-7 h-7 bg-cyan-500/20 text-cyan-400 rounded-full flex items-center justify-center text-sm font-bold">
                  2
                </span>
                <div>
                  <strong className="text-white">Extract and open terminal</strong>
                  <p className="text-sm text-slate-400 mt-1">
                    Unzip the file and navigate to the project folder in your terminal
                  </p>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-7 h-7 bg-cyan-500/20 text-cyan-400 rounded-full flex items-center justify-center text-sm font-bold">
                  3
                </span>
                <div>
                  <strong className="text-white">Install dependencies</strong>
                  <code className="block mt-2 bg-slate-950 px-4 py-2 rounded-lg text-cyan-300 text-sm">
                    pip install flask pandas numpy
                  </code>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-7 h-7 bg-cyan-500/20 text-cyan-400 rounded-full flex items-center justify-center text-sm font-bold">
                  4
                </span>
                <div>
                  <strong className="text-white">Run the application</strong>
                  <code className="block mt-2 bg-slate-950 px-4 py-2 rounded-lg text-cyan-300 text-sm">
                    python app.py
                  </code>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-7 h-7 bg-cyan-500/20 text-cyan-400 rounded-full flex items-center justify-center text-sm font-bold">
                  5
                </span>
                <div>
                  <strong className="text-white">Open in browser</strong>
                  <code className="block mt-2 bg-slate-950 px-4 py-2 rounded-lg text-cyan-300 text-sm">
                    http://localhost:5000
                  </code>
                </div>
              </li>
            </ol>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-emerald-400 mb-4">Features Included</h3>
            <ul className="space-y-2 text-slate-300 text-sm">
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
                2000 Player Dataset with comprehensive data
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
                6 Pages: Dashboard, Players, Analytics, Statistics, Predictions, Reports
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
                AI Chatbot with sports injury knowledge
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
                Dark/Light Mode Toggle
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
                ML Predictions & Risk Analysis
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
                Interactive Charts (Chart.js)
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
                Vertical Navigation Bar
              </li>
            </ul>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-blue-400 mb-4">Project Files</h3>
            <ul className="space-y-2 text-slate-300 text-sm font-mono">
              <li className="flex items-center gap-2">
                <span className="text-yellow-400">📄</span> app.py{" "}
                <span className="text-slate-500">- Flask server & routes</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-blue-400">📁</span> templates/
              </li>
              <li className="pl-6 flex items-center gap-2">
                <span className="text-orange-400">📄</span> base.html{" "}
                <span className="text-slate-500">- Layout & chatbot</span>
              </li>
              <li className="pl-6 flex items-center gap-2">
                <span className="text-orange-400">📄</span> home.html{" "}
                <span className="text-slate-500">- Dashboard</span>
              </li>
              <li className="pl-6 flex items-center gap-2">
                <span className="text-orange-400">📄</span> players.html{" "}
                <span className="text-slate-500">- Player list</span>
              </li>
              <li className="pl-6 flex items-center gap-2">
                <span className="text-orange-400">📄</span> analytics.html{" "}
                <span className="text-slate-500">- Charts</span>
              </li>
              <li className="pl-6 flex items-center gap-2">
                <span className="text-orange-400">📄</span> predictions.html{" "}
                <span className="text-slate-500">- ML predictions</span>
              </li>
              <li className="pl-6 flex items-center gap-2">
                <span className="text-orange-400">📄</span> reports.html{" "}
                <span className="text-slate-500">- Reports</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="text-center text-slate-500 text-sm">
          <p>Built with Flask, Python, Pandas, NumPy, Chart.js, and Bootstrap 5</p>
        </div>
      </div>
    </div>
  )
}
